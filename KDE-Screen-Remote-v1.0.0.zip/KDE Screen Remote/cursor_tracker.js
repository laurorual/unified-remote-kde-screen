// KDE Screen Remote - temporary KWin cursor bridge.
// Loaded only while the Unified Remote custom remote is active.

function reportCursor() {
    var pos = workspace.cursorPos;

    // Send strings deliberately. This avoids QJS Number/QVariant numeric
    // type ambiguity across KWin / Qt / dbus-python.
    callDBus(
        "org.kdescreenremote.CursorTracker",
        "/CursorTracker",
        "org.kdescreenremote.CursorTracker",
        "ReportPosition",
        String(Math.round(pos.x)),
        String(Math.round(pos.y)),
        function() {}
    );
}

// Plasma 6 exposes this signal directly in the KWin scripting API.
// Event-driven tracking is both lighter and more accurate than polling.
workspace.cursorPosChanged.connect(reportCursor);

// Seed the helper immediately.
reportCursor();
